export default interface Animals {
    name: string,
    trait: string,
    power: number,
    id: string,
  }